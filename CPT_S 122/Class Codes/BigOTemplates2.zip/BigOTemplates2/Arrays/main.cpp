// This example studies sequential/linear search, binary search,
// selection sort, and bubble sort to explore Big-O analysis

// History: 7/12 - Implemented sequentialSearch for
//                 algorithm analysis.

#include "BigO.h"

int main(void)
{
	BigO::SortsAndSearches<int> myObj;
	bool found = false;
	
	int list[5] = { 5, 3, 0, -1, 8 }, pos = 0;
	found = myObj.sequential_search(list, 5, 3, pos);

	cout << "result of sequential search: " << found << ", " << pos << endl;


	return 0;
}