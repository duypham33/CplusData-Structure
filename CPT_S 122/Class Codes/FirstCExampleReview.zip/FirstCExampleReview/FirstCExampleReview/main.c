//#include <stdio.h>
#include "Student.h"

int main(int argc, char* argv[])
{
	FILE* infile = fopen("data.csv", "r");

	if (infile != NULL)
	{
		printf("Opened file successfully!\n");

		Student_info data[100] = { {"", "", 0}, {"", "", 0} };
		char* pResult = NULL;
		int index = 0;

		char line[100] = ""; // empty string [0] = '\0'
		pResult = fgets(line, 100, infile); // read in the header line - discard

		while ((pResult = fgets(line, 100, infile)) != NULL)// (!feof(infile))
		{
			// pResult = fgets(line, 100, infile); // data line
			// separate the line
			// last name
			strcpy (data[index].last, strtok(line, ","));
			puts(data[index].last);
			// first name
			strcpy(data[index].first, strtok(NULL, ","));
			puts(data[index].first);
			// id number
			//strcpy(data[index].first, strtok(NULL, ","));
			data[index].id = atoi(strtok(NULL, "\n"));
			printf("%d\n", data[index].id);
			++index;
		}

		fclose(infile); // don't forget to programatically close the data file!
	}
}