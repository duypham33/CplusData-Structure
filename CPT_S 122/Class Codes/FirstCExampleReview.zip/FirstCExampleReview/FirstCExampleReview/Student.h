#ifndef STUDENT_H
#define STUDENT_H

#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef struct student_info
{
	char last[40];
	char first[40];
	unsigned int id;
} Student_info;

#endif
