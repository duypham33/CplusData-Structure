#ifndef LINKED_LIST_H
#define LINKED_LIST_H

#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <string.h>
#include <stdlib.h>  // malloc ()

// Recall a linked list consists of a sequence of nodes.
// Each node contains data and a pointer to the next node in sequence.

typedef struct data
{
	// describing student info
	char name[100]; // string
	unsigned int id;
} Data; // 104 bytes

// doubly linked list
typedef struct node
{
	Data student;
	struct node* pNext; // address for next node - link
	struct node* pPrev; // second link
} Node; // 108 bytes

typedef struct list
{
	Node* pHead;
} List;

void initList(List* pList); // set to empty list
Node* makeNode(const Data* const pNewData); // allocate space; init the space
int insertFront(List* pList, const Data* const pNewData);
int insertInOrder(List* pList, const Data* const pNewData); // insert ascending order based on ID
void printList(const List* pList);
int deleteNodeID(List* pList, unsigned int searchID);

#endif