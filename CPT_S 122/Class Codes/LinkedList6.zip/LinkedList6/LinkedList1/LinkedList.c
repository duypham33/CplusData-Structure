#include "LinkedList.h"

void initList(List* pList) // set to empty list
{
	pList->pHead = NULL;
}

Node* makeNode(const Data* const pNewData) // allocate space; init the space
{
	Node* pMem = NULL;

	// pNewData = &ofVariable;
	// pNewData->id = 11111111;

	// Node n1;

	// allocate space for a Node
	pMem = (Node *) malloc(sizeof(Node)); // allocates enough bytes for a Node, but doesn't init the space

	if (pMem != NULL) // checking to see if malloc () failed at getting our requested space
	{
		// guarantees that enough space was allocated for a Node
		pMem->pNext = NULL;
		pMem->pPrev = NULL;
		//pMem->student = *pNewData; // shallow copy
		// need to perform member-by-member copy so we can
		// get a fresh copy of the name field.
		pMem->student.id = pNewData->id;
		strcpy(pMem->student.name, pNewData->name);
	}

	return pMem;
}

int insertFront(List* pList, const Data* const pNewData)
{
	Node* pMem = makeNode(pNewData); // create space for node and init

	int success = 0; // failed to allocate space for a node

	if (pMem != NULL)
	{
		// space was allocated for a node
		success = 1;

		pMem->pNext = pList->pHead;
		pList->pHead->pPrev = pMem;
		pList->pHead = pMem;
	}

	return success;
}

void printList(const List* pList)
{
	Node* pCur = pList->pHead;

	printf("-->");

	while (pCur != NULL)
	{
		// data to print
		printf(" name: %s, id: %d -->", pCur->student.name,
			pCur->student.id);

		pCur = pCur->pNext;
	}
	putchar('\n');
}

// insert ascending order based on ID
int insertInOrder(List* pList, const Data* const pNewData) 
{
	int success = 0;

	Node* pMem = makeNode(pNewData), * pCur = pList->pHead,
		* pPrev = NULL;

	if (pMem != NULL)
	{
		// successfully allocate a node
		success = 1;

		// short-circuit evaluation
		while (pCur != NULL && pCur->student.id < pNewData->id)
		{
			// update pointers so that we can find the correct
			// position to insert
			pPrev = pCur;
			pCur = pCur->pNext;
		}

		if (pPrev != NULL)
		{
			// not inserting at the front - inserting in middle or end
			pMem->pNext = pCur;
			pPrev->pNext = pMem;
		}
		else
		{
			// inserting at front
			pMem->pNext = pList->pHead;
			pList->pHead = pMem;
		}
	}

	return success;
}

// precondition: list must not be empty!
int deleteNodeID(List* pList, unsigned int searchID)
{
	Node* pPrev = NULL, * pCur = pList->pHead;
	int success = 0; // we couldn't find the student

	while (pCur != NULL && 
		pCur->student.id != searchID) // walk through the list, searching for a specific ID number
	{
		pPrev = pCur;
		pCur = pCur->pNext;
	}

	// we found the student to remove or we reached the end of list
	if (pCur != NULL)
	{
		// we found the student in the list
		success = 1;

		if (pPrev != NULL)
		{
			if (pCur->pNext != NULL)
			{
				// deleting middle node
				pCur->pNext->pPrev = pPrev;
				pPrev->pNext = pCur->pNext;
			}
			else
			{
				// deleting end/last node
				pPrev->pNext = NULL;
			}

			// not removing first node/student in list
			//pPrev->pNext = pCur->pNext;
		}
		else
		{
			// removing first node/student in list
			pList->pHead = pCur->pNext;
			if (pList->pHead != NULL) // is there only one node in the list?
			{
				// more than one node in list
				pList->pHead->pPrev = NULL;
			}
		}

		// remove the student from list - free up memory
		free(pCur);
	}
	else
	{
		// student was not in list
		success = 0;
	}

	return success;
}