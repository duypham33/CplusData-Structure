// In this example we are building an application to store a class list of students.
// We are implementing a linked list.

// History: 2/5/21 - Started updating our linked list to transition it to
//                   a doubly linked list. Modified our struct node to
//                   accomodate a previous pointer. Modified makeNode (),
//                   insertFront (), and deleteNodeID ().
//          2/3/21 - Implemented deleteNodeID ().
//          2/1/21 - Implemented insertFront (), insertInOrder (), and printList ().
//          1/29/21 - Implemented initList (), makeNode ().
//          1/27/21 - Described a linked list. Defined the structs that will be involved with
//                    out linked list. See "LinkedList.h".

#include "LinkedList.h"

int main(int argc, char *argv[])
{
	List l;
	// didn't design a list struct
	Node* pHead = NULL;

	initList(&l);

	Data d1 = { "bob", 11111111 };
	//insertFront(&l, &d1);
	insertInOrder(&l, &d1);
	printList(&l);

	Data d2 = { "bill", 22222222 };
	//insertFront(&l, &d1);
	insertInOrder(&l, &d2);
	printList(&l);

	Data d3 = { "sara", 00000000 };
	//insertFront(&l, &d1);
	insertInOrder(&l, &d3);
	printList(&l);

	Data d4 = { "hanna", 15000000 };
	//insertFront(&l, &d1);
	insertInOrder(&l, &d4);
	printList(&l);

	int success = 0;
	success = deleteNodeID(&l, 8);
	printf("Success delete: %d\n", success);
	printList(&l);

	success = deleteNodeID(&l, 0);
	printf("Success delete: %d\n", success);
	printList(&l);

	success = deleteNodeID(&l, 22222222);
	printf("Success delete: %d\n", success);
	printList(&l);

	//printf("pHead: %d\n", l.pHead);

	return 0;
}